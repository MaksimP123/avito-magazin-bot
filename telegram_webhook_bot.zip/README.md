# Telegram Webhook Bot

Базовый шаблон Telegram-бота с поддержкой Webhook для Railway.

**Переменные окружения:**
- BOT_TOKEN — токен Telegram
- PORT — порт (обычно 8080)