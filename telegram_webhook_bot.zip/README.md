# Telegram Bot for Railway

## Установка
1. Залей проект на GitHub
2. Разверни в Railway
3. Укажи переменные окружения:
   - BOT_TOKEN — токен твоего Telegram-бота
   - PORT — порт (по умолчанию 8080)
